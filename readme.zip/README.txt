Thanks for downloading Risk of Rain: Return to Sender!

There's one thing you need to do before playing.

Take the provided "GMObject.lua" file and put it at the following location:

C:/[your RORML installation here]/ModLoader/resources/ModLoaderCore/API/class/object/

Replace the original "GMObject.lua" file. Don't worry, this won't break anything, it just allows RTS to access some things not normally accessible through the normal API.